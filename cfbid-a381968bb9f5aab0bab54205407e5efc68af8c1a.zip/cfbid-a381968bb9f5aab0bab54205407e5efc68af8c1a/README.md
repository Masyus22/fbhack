<h1 align="center">
  CFBID
</h1>
</div>
<p align="center">
  Made with ❤️ by <a href="https://github.com/anggaxd">Angga Kurniawan</a>
</p>
<p align="center">
 <img src="https://raw.githubusercontent.com/anggaxd/cfbid/main/20201005_120110.jpg" width="640" title="Menu" alt="Menu">
</p>

   ![](https://img.shields.io/badge/Language-2-blue) ![](https://img.shields.io/badge/Python-2.7-green) ![](https://img.shields.io/badge/Size-174Kb-orange) ![](https://img.shields.io/badge/Relase-20-08-20-brightgreen)

## Install script on Termux
```
$ pkg update && pkg upgrade
$ pkg install python2
$ pip2 install requests
$ pip2 install mechanize
$ pkg install git
$ git clone https://github.com/anggaxd/cfbid
```

## Run script
```
$ cd cfbid
$ python2 crack.py
```

## Informasi For Updates Script
* V1 (Fix Errors Installed)
* V2 (Fix Errors Clone Group)
* V3 (Done All Fix Error)
* V4 (Fix Login Email)

Notice Me : Please Don't Change Name Author
Thanks For Using My Script
